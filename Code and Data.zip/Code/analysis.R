library('tidyverse')
library('lmerTest')
library('patchwork')

###### Exp 1a ######
dat.1a_wide <- read.csv('./../Data/1a.csv', header = T, stringsAsFactors = T)

# target from different groups vs competitor from different groups
idx <- dat.1a_wide$group == 'different'
mean(dat.1a_wide$target[idx])
mean(dat.1a_wide$competitor[idx])
with(dat.1a_wide[idx,], t.test(target,competitor, paired = T))

# target from same group vs competitor from same group
idx <- dat.1a_wide$group == 'same'
mean(dat.1a_wide$target[idx])
mean(dat.1a_wide$competitor[idx])
with(dat.1a_wide[idx,], t.test(target,competitor, paired = T))

# target from same group vs target from different groups
mean(dat.1a_wide$target[dat.1a_wide$group == 'same'])
mean(dat.1a_wide$target[dat.1a_wide$group == 'different'])
t.test(dat.1a_wide$target[dat.1a_wide$group == 'same'], dat.1a_wide$target[dat.1a_wide$group == 'different'])

# decoy from same group vs decoy from different groups
mean(dat.1a_wide$decoy[dat.1a_wide$group == 'same'])
mean(dat.1a_wide$decoy[dat.1a_wide$group == 'different'])
t.test(dat.1a_wide$decoy[dat.1a_wide$group == 'same'], dat.1a_wide$decoy[dat.1a_wide$group == 'different'])

# bar plot
dat.1a <- gather(dat.1a_wide,'option','points',competitor,target,decoy)
dat.1a$option <- factor(dat.1a$option, levels = c('competitor', 'target', 'decoy'), ordered = T)
dat.1a$group <- factor(dat.1a$group, ordered = T)

pdf('./../Figures/1a.pdf', onefile=T, width = 4, height = 4)
p1 <- ggplot(dat.1a, aes(fill=option, group=option, x=group, y=points)) + 
  stat_summary(fun = mean, geom = 'bar', position=position_dodge()) +
  stat_summary(fun.data = mean_cl_boot, geom = 'errorbar', width = .1, position=position_dodge(.9)) +
  coord_cartesian(ylim = c(0, 100)) 
p1 + labs(x='Condition', y='Points', color=NULL, title='Experiment 1a') +
  scale_fill_manual(name=NULL, labels=c("Competitor","Target","Decoy"), values = c('#ffae49','#44a5c2','#105581')) +
  scale_x_discrete(labels=c("different" = "Different groups", "same" = "Same group")) + 
  theme(plot.title = element_text(hjust = 0.5),
        legend.position = c(0.8, 0.8))
dev.off()


###### Exp 1b ######
dat.1b_wide <- read.csv('./../Data/1b.csv', header = T, stringsAsFactors = T)

# target from different groups vs competitor from different groups
idx <- dat.1b_wide$group == 'different'
mean(dat.1b_wide$target[idx])
mean(dat.1b_wide$competitor[idx])
with(dat.1b_wide[idx,], t.test(target,competitor, paired = T))

# target from same group vs competitor from same group
idx <- dat.1b_wide$group == 'same'
mean(dat.1b_wide$target[idx])
mean(dat.1b_wide$competitor[idx])
with(dat.1b_wide[idx,], t.test(target,competitor, paired = T))

# target from same group vs target from different groups
mean(dat.1b_wide$target[dat.1b_wide$group == 'same'])
mean(dat.1b_wide$target[dat.1b_wide$group == 'different'])
t.test(dat.1b_wide$target[dat.1b_wide$group == 'same'], dat.1b_wide$target[dat.1b_wide$group == 'different'])

# bar plot
dat.1b <- gather(dat.1b_wide,'option','points',competitor,target)
dat.1b$option <- factor(dat.1b$option, levels = c('competitor', 'target'), ordered = T)
dat.1b$group <- factor(dat.1b$group, ordered = T)

pdf('./../Figures/1b.pdf', onefile=T, width = 4, height = 4)
p2 <- ggplot(dat.1b, aes(fill=option, group=option, x=group, y=points)) + 
  stat_summary(fun = mean, geom = 'bar', position=position_dodge()) +
  stat_summary(fun.data = mean_cl_boot, geom = 'errorbar', width = .1, position=position_dodge(.9)) +
  coord_cartesian(ylim = c(0, 100))
p2 + labs(x='Condition', y='Points', color=NULL, title='Experiment 1b') +
  scale_fill_manual(name=NULL, labels=c("Competitor","Target"), values = c('#ffae49','#44a5c2')) +
  scale_x_discrete(labels=c("different" = "Different groups", "same" = "Same group")) + 
  theme(plot.title = element_text(hjust = 0.5),
        legend.position = c(0.8, 0.8))
dev.off()


###### Exp 2a ######
dat.2a <- read.csv('./../Data/2a.csv', header = T, stringsAsFactors = T)
dat.2a$condition <- factor(dat.2a$condition)
dat.2a$subject <- as.factor(dat.2a$subject)
lme_2a <- lmer(target_mine_estimate ~ target_mine_sample + decoy_mine_sample + competitor_mine_sample + condition + 
                 target_mine_sample:condition + decoy_mine_sample:condition + competitor_mine_sample:condition +
                 (1|subject) + (target_mine_sample+0|subject) + (decoy_mine_sample+0|subject) + (competitor_mine_sample+0|subject) + (condition+0|subject) +
                 (target_mine_sample:condition+0|subject) + (decoy_mine_sample:condition+0|subject) + (competitor_mine_sample:condition+0|subject),
               data = dat.2a)
summary(lme_2a)
f <- fixef(lme_2a)

# plot regression
lme_2a_c1 <- lmer(target_mine_estimate ~ target_mine_sample + decoy_mine_sample + competitor_mine_sample + (1|subject) + (target_mine_sample+0|subject) + (decoy_mine_sample+0|subject) + (competitor_mine_sample+0|subject),
                  data = dat.2a %>% filter(condition==0))
summary(lme_2a_c1)
f1 <- fixef(lme_2a_c1)
ci1 <- confint(lme_2a_c1)

lme_2a_c2 <- lmer(target_mine_estimate ~ target_mine_sample + decoy_mine_sample + competitor_mine_sample + (1|subject) + (target_mine_sample+0|subject) + (decoy_mine_sample+0|subject) + (competitor_mine_sample+0|subject),
                  data = dat.2a %>% filter(condition==1))
summary(lme_2a_c2)
f2 <- fixef(lme_2a_c2)
ci2 <- confint(lme_2a_c2)

intercept <- data.frame(condition=c(0,1), coefficient = c(f['(Intercept)'],f['(Intercept)']+f['condition1']), upper = c(ci1['(Intercept)',1]-f1['(Intercept)']+f['(Intercept)'],ci2['(Intercept)',1]-f2['(Intercept)']+f['(Intercept)']+f['condition1']), lower = c(ci1['(Intercept)',2]-f1['(Intercept)']+f['(Intercept)'],ci2['(Intercept)',2]-f2['(Intercept)']+f['(Intercept)']+f['condition1']))
target_mine_sample <- data.frame(condition=c(0,1), coefficient = c(f['target_mine_sample'],f['target_mine_sample']+f['target_mine_sample:condition1']), upper = c(ci1['target_mine_sample',1]-f1['target_mine_sample']+f['target_mine_sample'],ci2['target_mine_sample',1]-f2['target_mine_sample']+f['target_mine_sample']+f['target_mine_sample:condition1']), lower = c(ci1['target_mine_sample',2]-f1['target_mine_sample']+f['target_mine_sample'],ci2['target_mine_sample',2]-f2['target_mine_sample']+f['target_mine_sample']+f['target_mine_sample:condition1']))
decoy_mine_sample <- data.frame(condition=c(0,1), coefficient = c(f['decoy_mine_sample'],f['decoy_mine_sample']+f['decoy_mine_sample:condition1']), upper = c(ci1['decoy_mine_sample',1]-f1['decoy_mine_sample']+f['decoy_mine_sample'],ci2['decoy_mine_sample',1]-f2['decoy_mine_sample']+f['decoy_mine_sample']+f['decoy_mine_sample:condition1']), lower = c(ci1['decoy_mine_sample',2]-f1['decoy_mine_sample']+f['decoy_mine_sample'],ci2['decoy_mine_sample',2]-f2['decoy_mine_sample']+f['decoy_mine_sample']+f['decoy_mine_sample:condition1']))
competitor_mine_sample <- data.frame(condition=c(0,1), coefficient = c(f['competitor_mine_sample'],f['competitor_mine_sample']+f['competitor_mine_sample:condition1']), upper = c(ci1['competitor_mine_sample',1]-f1['competitor_mine_sample']+f['competitor_mine_sample'],ci2['competitor_mine_sample',1]-f2['competitor_mine_sample']+f['competitor_mine_sample']+f['competitor_mine_sample:condition1']), lower = c(ci1['competitor_mine_sample',2]-f1['competitor_mine_sample']+f['competitor_mine_sample'],ci2['competitor_mine_sample',2]-f2['competitor_mine_sample']+f['competitor_mine_sample']+f['competitor_mine_sample:condition1']))

intercept$condition <- as.factor(intercept$condition)
target_mine_sample$condition <- as.factor(target_mine_sample$condition)
decoy_mine_sample$condition <- as.factor(decoy_mine_sample$condition)
competitor_mine_sample$condition <- as.factor(competitor_mine_sample$condition)

pdf('./../Figures/2a.pdf', onefile=T, width = 6, height = 4)
p1 <- intercept %>% ggplot(aes(condition, coefficient, color = condition)) +
  geom_point() +
  geom_errorbar(aes(condition, ymin = lower, ymax = upper), width = .1) +
  coord_cartesian(ylim = c(0, 11)) + 
  labs(x='Noise/Dispersion', y='Coefficient', title='Intercept') +
  scale_x_discrete(labels=c("0" = "Low", "1" = "High")) +
  theme_classic() +
  theme(legend.position = 'none',
        plot.title = element_text(hjust = 0.5, size = 10),
        axis.title=element_text(size=8),
        axis.text=element_text(size=8))

p2 <- target_mine_sample %>% ggplot(aes(condition, coefficient, color = condition)) +
  geom_point() +
  geom_errorbar(aes(condition, ymin = lower, ymax = upper), width = .1) +
  coord_cartesian(ylim = c(0.70,1)) + 
  labs(x='Noise/Dispersion', y=NULL, title='Target mine') +
  scale_x_discrete(labels=c("0" = "Low", "1" = "High")) +
  theme_classic() +
  theme(legend.position = 'none',
        plot.title = element_text(hjust = 0.5, size = 10),
        axis.title=element_text(size=8),
        axis.text=element_text(size=8))

p3 <- decoy_mine_sample %>% ggplot(aes(condition, coefficient, color = condition)) +
  geom_point() +
  geom_errorbar(aes(condition, ymin = lower, ymax = upper), width = .1) +
  coord_cartesian(ylim = c(-0.02,0.12)) +
  labs(x='Noise/Dispersion', y=NULL, title='Decoy mine') +
  scale_x_discrete(labels=c("0" = "Low", "1" = "High")) +
  theme_classic() +
  theme(legend.position = 'none',
        plot.title = element_text(hjust = 0.5, size = 10),
        axis.title=element_text(size=8),
        axis.text=element_text(size=8))

p4 <- competitor_mine_sample %>% ggplot(aes(condition, coefficient, color = condition)) +
  geom_point() +
  geom_errorbar(aes(condition, ymin = lower, ymax = upper), width = .1) +
  coord_cartesian(ylim = c(-0.04,0.08)) +
  labs(x='Noise/Dispersion', y=NULL, title='Competitor mine') +
  scale_x_discrete(labels=c("0" = "Low", "1" = "High")) +
  theme_classic() +
  theme(legend.position = 'none',
        plot.title = element_text(hjust = 0.5, size = 10),
        axis.title=element_text(size=8),
        axis.text=element_text(size=8))

p1 | p2 | p3 | p4
dev.off()


###### Exp 2b ######
dat.2b <- read.csv('./../Data/2b.csv', header = T, stringsAsFactors = T)
dat.2b$condition <- factor(dat.2b$condition)
dat.2b$subject <- as.factor(dat.2b$subject)
dat.2b <- na.omit(dat.2b)

lme_2b <- lmer(target_mine_estimate ~ target_mine_sample + decoy_mine_sample + competitor_mine_sample + condition + 
                 target_mine_sample:condition + decoy_mine_sample:condition + competitor_mine_sample:condition +
                 (1|subject) + (target_mine_sample+0|subject) + (decoy_mine_sample+0|subject) + (competitor_mine_sample+0|subject) + (condition+0|subject) +
                 (target_mine_sample:condition+0|subject) + (decoy_mine_sample:condition+0|subject) + (competitor_mine_sample:condition+0|subject),
               data = dat.2b)
summary(lme_2b)
f <- fixef(lme_2b)

dat.2b_no_pool <- dat.2b %>% filter(duplicate == 0)
dat.2b_no_pool$condition <- factor(dat.2b_no_pool$condition)
dat.2b_no_pool$subject <- as.factor(dat.2b_no_pool$subject)
dat.2b_no_pool <- na.omit(dat.2b_no_pool)
low_noise_percent_correct <- mean(dat.2b_no_pool$correct[dat.2b_no_pool$condition==0])
high_noise_percent_correct <- mean(dat.2b_no_pool$correct[dat.2b_no_pool$condition==1])

percent_correct <- dat.2b_no_pool %>% 
  group_by(subject,condition) %>%
  dplyr::summarize(avg_correct = mean(correct))
with(percent_correct, t.test(avg_correct[condition==1], avg_correct[condition==0], paired = T))

# plot regression
lme_2b_c1 <- lmer(target_mine_estimate ~ target_mine_sample + decoy_mine_sample + competitor_mine_sample + (1|subject) + (target_mine_sample+0|subject) + (decoy_mine_sample+0|subject) + (competitor_mine_sample+0|subject),
                  data = dat.2b %>% filter(condition==0))
summary(lme_2b_c1)
f1 <- fixef(lme_2b_c1)
ci1 <- confint(lme_2b_c1)

lme_2b_c2 <- lmer(target_mine_estimate ~ target_mine_sample + decoy_mine_sample + competitor_mine_sample + (1|subject) + (target_mine_sample+0|subject) + (decoy_mine_sample+0|subject) + (competitor_mine_sample+0|subject),
                  data = dat.2b %>% filter(condition==1))
summary(lme_2b_c2)
f2 <- fixef(lme_2b_c2)
ci2 <- confint(lme_2b_c2)

intercept <- data.frame(condition=c(0,1), coefficient = c(f['(Intercept)'],f['(Intercept)']+f['condition1']), upper = c(ci1['(Intercept)',1]-f1['(Intercept)']+f['(Intercept)'],ci2['(Intercept)',1]-f2['(Intercept)']+f['(Intercept)']+f['condition1']), lower = c(ci1['(Intercept)',2]-f1['(Intercept)']+f['(Intercept)'],ci2['(Intercept)',2]-f2['(Intercept)']+f['(Intercept)']+f['condition1']))
target_mine_sample <- data.frame(condition=c(0,1), coefficient = c(f['target_mine_sample'],f['target_mine_sample']+f['target_mine_sample:condition1']), upper = c(ci1['target_mine_sample',1]-f1['target_mine_sample']+f['target_mine_sample'],ci2['target_mine_sample',1]-f2['target_mine_sample']+f['target_mine_sample']+f['target_mine_sample:condition1']), lower = c(ci1['target_mine_sample',2]-f1['target_mine_sample']+f['target_mine_sample'],ci2['target_mine_sample',2]-f2['target_mine_sample']+f['target_mine_sample']+f['target_mine_sample:condition1']))
decoy_mine_sample <- data.frame(condition=c(0,1), coefficient = c(f['decoy_mine_sample'],f['decoy_mine_sample']+f['decoy_mine_sample:condition1']), upper = c(ci1['decoy_mine_sample',1]-f1['decoy_mine_sample']+f['decoy_mine_sample'],ci2['decoy_mine_sample',1]-f2['decoy_mine_sample']+f['decoy_mine_sample']+f['decoy_mine_sample:condition1']), lower = c(ci1['decoy_mine_sample',2]-f1['decoy_mine_sample']+f['decoy_mine_sample'],ci2['decoy_mine_sample',2]-f2['decoy_mine_sample']+f['decoy_mine_sample']+f['decoy_mine_sample:condition1']))
competitor_mine_sample <- data.frame(condition=c(0,1), coefficient = c(f['competitor_mine_sample'],f['competitor_mine_sample']+f['competitor_mine_sample:condition1']), upper = c(ci1['competitor_mine_sample',1]-f1['competitor_mine_sample']+f['competitor_mine_sample'],ci2['competitor_mine_sample',1]-f2['competitor_mine_sample']+f['competitor_mine_sample']+f['competitor_mine_sample:condition1']), lower = c(ci1['competitor_mine_sample',2]-f1['competitor_mine_sample']+f['competitor_mine_sample'],ci2['competitor_mine_sample',2]-f2['competitor_mine_sample']+f['competitor_mine_sample']+f['competitor_mine_sample:condition1']))

intercept$condition <- as.factor(intercept$condition)
target_mine_sample$condition <- as.factor(target_mine_sample$condition)
decoy_mine_sample$condition <- as.factor(decoy_mine_sample$condition)
competitor_mine_sample$condition <- as.factor(competitor_mine_sample$condition)

pdf('./../Figures/2b.pdf', onefile=T, width = 6, height = 4)
p1 <- intercept %>% ggplot(aes(condition, coefficient, color = condition)) +
  geom_point() +
  geom_errorbar(aes(condition, ymin = lower, ymax = upper), width = .1) +
  coord_cartesian(ylim = c(3, 18)) + 
  labs(x='Style Noise', y='Coefficient', title='Intercept') +
  scale_x_discrete(labels=c("0" = "Low", "1" = "High")) +
  theme_classic() +
  theme(legend.position = 'none',
        plot.title = element_text(hjust = 0.5, size = 10),
        axis.title=element_text(size=8),
        axis.text=element_text(size=8))

p2 <- target_mine_sample %>% ggplot(aes(condition, coefficient, color = condition)) +
  geom_point() +
  geom_errorbar(aes(condition, ymin = lower, ymax = upper), width = .1) +
  coord_cartesian(ylim = c(0.78,0.97)) + 
  labs(x='Style Noise', y=NULL, title='Target mine') +
  scale_x_discrete(labels=c("0" = "Low", "1" = "High")) +
  theme_classic() +
  theme(legend.position = 'none',
        plot.title = element_text(hjust = 0.5, size = 10),
        axis.title=element_text(size=8),
        axis.text=element_text(size=8))

p3 <- decoy_mine_sample %>% ggplot(aes(condition, coefficient, color = condition)) +
  geom_point() +
  geom_errorbar(aes(condition, ymin = lower, ymax = upper), width = .1) +
  coord_cartesian(ylim = c(-0.04,0.1)) +
  labs(x='Style Noise', y=NULL, title='Decoy mine') +
  scale_x_discrete(labels=c("0" = "Low", "1" = "High")) +
  theme_classic() +
  theme(legend.position = 'none',
        plot.title = element_text(hjust = 0.5, size = 10),
        axis.title=element_text(size=8),
        axis.text=element_text(size=8))

p4 <- competitor_mine_sample %>% ggplot(aes(condition, coefficient, color = condition)) +
  geom_point() +
  geom_errorbar(aes(condition, ymin = lower, ymax = upper), width = .1) +
  coord_cartesian(ylim = c(-0.02,0.05)) +
  labs(x='Style Noise', y=NULL, title='Competitor mine') +
  scale_x_discrete(labels=c("0" = "Low", "1" = "High")) +
  theme_classic() +
  theme(legend.position = 'none',
        plot.title = element_text(hjust = 0.5, size = 10),
        axis.title=element_text(size=8),
        axis.text=element_text(size=8))

p1 | p2 | p3 | p4
dev.off()

